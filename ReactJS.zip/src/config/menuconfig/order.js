export const order = {
  id: "MENU_ORDER",
  icon: "FaBoxOpen",
  text: "Order",
  child: [
    {
      id: "MENU_ORDER.ORDER",
      path: "/order",
      isPublic: true,
      text: "Order",
      child: []
    }
  ]
}
