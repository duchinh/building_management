export const demo = {
  id: "MENU_DEMO",
  icon: "DashboardIcon",
  text: "Dashboard",
  child: [
    {
      id: "MENU_DEMO.DEMO",
      path: "/demo",
      isPublic: true,
      text: "Demo",
      child: [],
    },
  ],
};
