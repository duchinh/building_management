export const customer = {
  id: "MENU_CUSTOMER",
  icon: "FaUser",
  text: "Customer",
  child: [
    {
      id: "MENU_CUSTOMER.CUSTOMER",
      path: "/customer",
      isPublic: true,
      text: "Customer",
      child: []
    }
  ]
}
