export const general = {
  id: "MENU_GENERAL",
  icon: "DashboardIcon",
  text: "Dashboard",
  child: [
    {
      id: "MENU_GENERAL.DASHBOARD",
      path: "/",
      isPublic: true,
      text: "Dashboard",
      child: [],
    },
  ],
};
