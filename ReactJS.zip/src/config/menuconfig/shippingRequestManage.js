export const shippingRequestManage = {
  id: "MENU_SHIPPING_REQUEST_MANAGE",
  icon: "FaTruckFast",
  text: "Shipping request manage",
  child: [
    {
      id: "MENU_SHIPPING_REQUEST_MANAGE.SHIPPING_REQUEST_MANAGE",
      path: "/shipping-request-manage",
      isPublic: true,
      text: "Shipping request manage",
      child: []
    }
  ]
}
