export const vehicle = {
  id: "MENU_VEHICLE",
  icon: "MdDirectionsCar",
  text: "Vehicle",
  child: [
    {
      id: "MENU_VEHICLE.VEHICLE",
      path: "/vehicle",
      isPublic: true,
      text: "Vehicle",
      child: []
    }
  ]
}
