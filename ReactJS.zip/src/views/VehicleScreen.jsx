const VehicleScreen = () => {
  return (
    <div>
      <h1>Vehicle Screen</h1>
    </div>
  );
}

export default VehicleScreen;
